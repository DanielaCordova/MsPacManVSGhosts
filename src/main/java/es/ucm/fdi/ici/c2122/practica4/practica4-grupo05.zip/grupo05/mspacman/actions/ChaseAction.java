package es.ucm.fdi.ici.c2122.practica4.grupo05.mspacman.actions;

import java.util.Collections;
import java.util.HashMap;
import java.util.TreeMap;

import es.ucm.fdi.ici.Action;
import es.ucm.fdi.ici.c2122.practica4.grupo05.mspacman.MsPacManFuzzyMemory;
import es.ucm.fdi.ici.c2122.practica4.grupo05.utils.Moves;
import pacman.game.Game;
import pacman.game.Constants.DM;
import pacman.game.Constants.GHOST;
import pacman.game.Constants.MOVE;

public class ChaseAction  implements Action {


	private GHOST g;
	private MsPacManFuzzyMemory fuzzyMemory;
	
	public ChaseAction(MsPacManFuzzyMemory f, GHOST g) {
		// TODO Auto-generated constructor stub
		this.fuzzyMemory=f;
		this.g=g;
	}

	public MOVE execute(Game game) {
	
	
		int pos = fuzzyMemory.getLastVisiblePosition(g);
		
		return Moves.pacmanTowards(game, pos);
	}

	public String getActionId() {
		return "Chase"+ this.g.name();
	}

	

}